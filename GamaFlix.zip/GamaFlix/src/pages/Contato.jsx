import React from 'react';

const Contato = () => {
  return (
    <div className="container mx-auto py-8 flex flex-col justify-center items-center min-h-screen">
      <h1 className="text-4xl font-bold mb-6">
        <span className="text-black">Gama</span>
        <span className="text-secondary-gama2">Flix</span>
        <span className="text-black"> contato</span>
      </h1>
    </div>
  );
};

export default Contato;
