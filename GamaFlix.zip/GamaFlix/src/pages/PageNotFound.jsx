function PageNotFound() {
    return (
        <h1> PageNotFound</h1>
    );
}

export default PageNotFound